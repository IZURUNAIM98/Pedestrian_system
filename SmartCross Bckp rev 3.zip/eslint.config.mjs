import { defineConfig, globalIgnores } from "eslint/config";
import nextVitals from "eslint-config-next/core-web-vitals";
import nextTypescript from "eslint-config-next/typescript";

export default defineConfig([
  ...nextVitals,
  ...nextTypescript,
  globalIgnores([
    ".next/**",
    ".artifact_runtime/**",
    "backup Rev 2/**",
    "outputs/**",
    "playwright-report/**",
    "test-results/**",
    "tmp/**",
  ]),
]);
